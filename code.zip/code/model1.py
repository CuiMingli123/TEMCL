import torch
import torch.nn as nn
import torch.nn.functional as F
import random
from Contrast import Contrast
from Metapath_Augmentation.mp_encoder import Mp_encoder
from Structural_Augmentation.st_encoder import St_encoder
import os
import numpy as np
import itertools
from collections import Counter
import time
import pandas as pd
import math
from torch.nn.parameter import Parameter
from torch.nn import TransformerEncoder, TransformerEncoderLayer
from sklearn.neighbors import NearestNeighbors


import random
torch.manual_seed(123)
random.seed(123)


def dynamic_knn(similarity_matrix, k_min=5, k_max=15):
    n = similarity_matrix.shape[0]  # 药物数量
    dynamic_k_values = np.zeros(n, dtype=int)  # 存储每个药物的动态K值

    for i in range(n):
        similarities = similarity_matrix[i]
        mean_sim = np.mean(similarities)
        k_value = int(np.interp(mean_sim, (0, 1), (k_max, k_min)))
        k_value = max(k_min, min(k_value, k_max))

        dynamic_k_values[i] = k_value

    return dynamic_k_values

def build_hypergraph_matrix(similarity_matrix, dynamic_k_values):
    n = similarity_matrix.shape[0]  # 药物数量
    hypergraph_matrix = np.zeros((n, n), dtype=int)  # 初始化超图矩阵

    for i in range(n):
        k_value = dynamic_k_values[i]

        top_k_indices = np.argsort(similarity_matrix[i])[-k_value-1:-1][::-1]

        hypergraph_matrix[i, i] = 1
        for neighbor in top_k_indices:
            hypergraph_matrix[neighbor, i] = 1

    return hypergraph_matrix


# 定义GCN层
class GraphConvolution(nn.Module):
    def __init__(self, in_features, out_features):
        super(GraphConvolution, self).__init__()
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        self.bias = nn.Parameter(torch.FloatTensor(out_features))
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.weight)
        nn.init.zeros_(self.bias)

    def forward(self, input, adj):
        support = torch.mm(input, self.weight)
        output = torch.spmm(adj, support)
        return output + self.bias

# 定义GCN网络
class GCN(nn.Module):
    def __init__(self, nfeat, nhid1, nhid2):
        super(GCN, self).__init__()
        self.gc1 = GraphConvolution(nfeat, nhid1)
        self.gc2 = GraphConvolution(nhid1, nhid2)

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = self.gc2(x, adj)
        return x


# 定义图注意力层
class GraphAttentionLayer(nn.Module):
    def __init__(self, in_features, out_features, dropout, alpha):
        super(GraphAttentionLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.dropout = dropout
        self.alpha = alpha

        self.W = nn.Parameter(torch.empty(size=(in_features, out_features)))
        nn.init.xavier_uniform_(self.W.data, gain=1.414)
        self.a = nn.Parameter(torch.empty(size=(2 * out_features, 1)))
        nn.init.xavier_uniform_(self.a.data, gain=1.414)

        self.leakyrelu = nn.LeakyReLU(self.alpha)

    def forward(self, h, adj):
        Wh = torch.mm(h, self.W)
        N = Wh.size()[0]

        a_input = torch.cat([Wh.repeat(1, N).view(N * N, -1), Wh.repeat(N, 1)], dim=1).view(N, -1,
                                                                                            2 * self.out_features)
        e = self.leakyrelu(torch.matmul(a_input, self.a).squeeze(2))

        zero_vec = -9e15 * torch.ones_like(e)
        attention = torch.where(adj > 0, e, zero_vec)
        attention = F.softmax(attention, dim=1)
        attention = F.dropout(attention, self.dropout, training=self.training)
        h_prime = torch.matmul(attention, Wh)

        return h_prime

class GAT(nn.Module):
    def __init__(self, nfeat, nhid, dropout, alpha):
        super(GAT, self).__init__()
        self.dropout = dropout
        self.attentions = [GraphAttentionLayer(nfeat, nhid, dropout=dropout, alpha=alpha)]

    def forward(self, x, adj):
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.attentions[0](x, adj)
        return x


def Eu_dis(x):
    """
    Calculate the distance among each raw of x
    :param x: N X D
                N: the object number
                D: Dimension of the feature
    :return: N X N distance matrix
    """
    x=x
    x = np.mat(x)
    aa = np.sum(np.multiply(x, x), 1)
    ab = x * x.T
    dist_mat = aa + aa.T - 2 * ab
    dist_mat[dist_mat < 0] = 0
    dist_mat = np.sqrt(dist_mat)
    dist_mat = np.maximum(dist_mat, dist_mat.T)
    return dist_mat


def feature_concat(*F_list, normal_col=False):
    """
    Concatenate multiple modality feature. If the dimension of a feature matrix is more than two,
    the function will reduce it into two dimension(using the last dimension as the feature dimension,
    the other dimension will be fused as the object dimension)
    :param F_list: Feature matrix list
    :param normal_col: normalize each column of the feature
    :return: Fused feature matrix
    """
    features = None
    for f in F_list:
        if f is not None and f != []:
            # deal with the dimension that more than two
            if len(f.shape) > 2:
                f = f.reshape(-1, f.shape[-1])
            # normal each column
            if normal_col:
                f_max = np.max(np.abs(f), axis=0)
                f = f / f_max
            # facing the first feature matrix appended to fused feature matrix
            if features is None:
                features = f
            else:
                features = np.hstack((features, f))
    if normal_col:
        features_max = np.max(np.abs(features), axis=0)
        features = features / features_max
    return features


def hyperedge_concat(*H_list):
    """
    Concatenate hyperedge group in H_list
    :param H_list: Hyperedge groups which contain two or more hypergraph incidence matrix
    :return: Fused hypergraph incidence matrix
    """
    H = None
    for h in H_list:
        if h is not None and h != []:
            # for the first H appended to fused hypergraph incidence matrix
            if H is None:
                H = h
            else:
                if type(h) != list:
                    H = np.hstack((H, h))
                else:
                    tmp = []
                    for a, b in zip(H, h):
                        tmp.append(np.hstack((a, b)))
                    H = tmp
    return H


def generate_G_from_H(H, variable_weight=False):
    """
    calculate G from hypgraph incidence matrix H
    :param H: hypergraph incidence matrix H
    :param variable_weight: whether the weight of hyperedge is variable
    :return: G
    """
    if type(H) != list:
        return _generate_G_from_H(H, variable_weight)
    else:
        G = []
        for sub_H in H:
            G.append(generate_G_from_H(sub_H, variable_weight))
        return G

def _generate_G_from_H(H, variable_weight=False):
    """
    calculate G from hypgraph incidence matrix H
    :param H: hypergraph incidence matrix H
    :param variable_weight: whether the weight of hyperedge is variable
    :return: G
    """
    H = np.array(H)
    n_edge = H.shape[1]
    # the weight of the hyperedge
    W = np.ones(n_edge)
    # the degree of the node
    DV = np.sum(H * W, axis=1)
    # the degree of the hyperedge
    DE = np.sum(H, axis=0)
    new_matrix=np.diag(np.power(DE, -1))
    new_matrix[np.isnan(new_matrix) | np.isinf(new_matrix)] = 0.0
    invDE = np.mat(new_matrix)
    new_matrix=np.diag(np.power(DV, -0.5))
    new_matrix[np.isnan(new_matrix) | np.isinf(new_matrix)] = 0.0
    DV2 = np.mat(new_matrix)
    W = np.mat(np.diag(W))
    H = np.mat(H)
    HT = H.T

    if variable_weight:
        DV2_H = DV2 * H
        invDE_HT_DV2 = invDE * HT * DV2
        return DV2_H, W, invDE_HT_DV2
    else:
        G = DV2 * H * W * invDE * HT * DV2
        return G

def build_hypergraph(sim, num_neighbor):
    if num_neighbor > sim.shape[0] or num_neighbor < 0:
        num_neighbor = sim.shape[0]
    neighbor = np.argpartition(-sim, kth=num_neighbor, axis=1)[:, :num_neighbor]
    row_index = np.arange(neighbor.shape[0]).repeat(neighbor.shape[1])
    col_index = neighbor.reshape(-1)
    zero=np.zeros((sim.shape[0],sim.shape[1]))
    zero[row_index, col_index]=sim[row_index, col_index]
    return zero
def build_muti_hypergraph(sim, num_neighbor):
    if num_neighbor > sim.shape[0] or num_neighbor < 0:
        num_neighbor = sim.shape[0]
    neighbor = np.argpartition(-sim, kth=num_neighbor, axis=1)[:, :num_neighbor]
    row_index = np.arange(neighbor.shape[0]).repeat(neighbor.shape[1])
    col_index = neighbor.reshape(-1)
    zero=np.zeros((sim.shape[0],sim.shape[1]))
    zero[row_index, col_index]=sim[row_index, col_index]
    return zero

#实际为构建Gr
def loadGR1(mm):

    dig=np.ones(mm.shape[0])
    I=np.diag(dig)
    H=mm+I
    G =_generate_G_from_H(H)
    return G
#实际为构建Gd
def loadGD1(dd):
    dig = np.ones(dd.shape[0])
    I = np.diag(dig)
    H = dd+I
    G =_generate_G_from_H(H)
    return G

def generate_association_matrix(similarity_matrix):
    n = similarity_matrix.shape[0]
    association_matrix = np.zeros_like(similarity_matrix, dtype=int)

    for i in range(n):
        sorted_indices = np.argsort(similarity_matrix[i])[::-1]
        association_matrix[i, sorted_indices[:7]] = 1

    return association_matrix

class HGNN_conv(nn.Module):
    def __init__(self, in_ft, out_ft, bias=True):
        super(HGNN_conv, self).__init__()
        self.dropout = nn.Dropout(0.4)
        self.weight = Parameter(torch.Tensor(in_ft, out_ft))
        self.act = nn.ReLU()
        if bias:
           # self.bias = Parameter(torch.Tensor(out_ft))
            self.bias = nn.Parameter(torch.zeros(out_ft))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()
    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        torch.nn.init.xavier_uniform_(self.weight)
    def forward(self, x: torch.Tensor, G: torch.Tensor):
        # x = torch.matmul(x, self.weight.cuda())
        x = torch.matmul(x, self.weight)
        x = G@x
        if self.bias is not None:
            # x = x + self.bias.cuda()
            x = x + self.bias
        return x
class HGNN_fc(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(HGNN_fc, self).__init__()
        self.fc = nn.Linear(in_ch, out_ch)

    def forward(self, x):
        return self.fc(x)


class HGNN_embedding(nn.Module):
    def __init__(self, in_ch, n_hid, dropout=0.5):
        super(HGNN_embedding, self).__init__()
        self.dropout = dropout
        self.hgc1 = HGNN_conv(in_ch, n_hid)
        self.hgc2 = HGNN_conv(n_hid, n_hid)

    def forward(self, x, G):
        x = F.relu(self.hgc1(x, G))
        x = F.dropout(x, self.dropout)
        x = F.relu(self.hgc2(x, G))
        return x


# class TransClassifier(nn.Module):
#     def __init__(self, input_dim, hidden_dim, num_layers, num_classes):
#         super(TransClassifier, self).__init__()
#         self.model_type = 'Transformer'
#         encoder_layers = TransformerEncoderLayer(d_model=hidden_dim, nhead=4)#初始为8
#         self.transformer_encoder = TransformerEncoder(encoder_layers, num_layers=num_layers)
#         self.decoder = nn.Linear(hidden_dim, num_classes)
#     def forward(self, src):
#         out = self.transformer_encoder(src)
#         out = self.decoder(out)
#         return out[0]

class TransClassifier(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, num_classes):
        super(TransClassifier, self).__init__()
        self.model_type = 'Transformer'
        encoder_layers = TransformerEncoderLayer(d_model=hidden_dim, nhead=8)
        self.transformer_encoder = TransformerEncoder(encoder_layers, num_layers=num_layers)
        self.decoder = nn.Linear(hidden_dim, num_classes)
    def forward(self, src):
        out = self.transformer_encoder(src)
        out = self.decoder(out)
        return out[0]



class MAHGCL(nn.Module):
    def __init__(self, args):
        super(MAHGCL, self).__init__()
        self.args = args
        self.mp = Mp_encoder(self.args)
        self.st = St_encoder(self.args)
        self.contrast_r = Contrast(self.args)
        self.contrast_d = Contrast(self.args)
        self.n_neg = self.args.n_neg
        self.pool = self.args.pool
        # 进行维度和层数的选参实验
        self.HGNN = HGNN_embedding(args.hgt_in_dim, args.hgt_out_dim)
        # 回复审稿意见补充的
        self.GCN = GCN(64,64,64)
        self.GAT = GAT(64, 64, dropout=0.6, alpha=0.2)

        #构建超图k的取值
        self.hyperedge_k = 20 #20


        #采用transformer进行分类
        #self.transformer_class=TransClassifier(256,128,1,2)


        # 进行维度和层数的选参实验，Cdataset最终结果：层数为3，维度为64
        self.transformer_drug = TransClassifier(args.hgt_in_dim, args.hgt_in_dim, 3, args.hgt_out_dim)
        self.transformer_disease = TransClassifier(args.hgt_in_dim, args.hgt_in_dim, 3, args.hgt_out_dim)
        self.transformer_protein = TransClassifier(args.hgt_in_dim, args.hgt_in_dim, 3, args.hgt_out_dim)


        #将初始特征映射到同一空间中，根据数据集进行选择
        #Cdataset
        self.drug_linear = nn.Linear(663, args.hgt_in_dim)
        self.disease_linear = nn.Linear(409, args.hgt_in_dim)
        self.protein_linear = nn.Linear(993, args.hgt_in_dim)



        self.hidden_dim = args.hgt_out_dim


        self.mlp = nn.Sequential(
            nn.Linear(self.args.hgt_out_dim, 1024),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(1024, 1024),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(1024, 256),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(256, 2)
        )

        #为了进行对比学习的消融实验， A and B时，为了适应维度变化
        # self.mlp = nn.Sequential(
        #     nn.Linear(self.args.hgt_out_dim*2, 1024),
        #     nn.ReLU(),
        #     nn.Dropout(0.4),
        #     nn.Linear(1024, 1024),
        #     nn.ReLU(),
        #     nn.Dropout(0.4),
        #     nn.Linear(1024, 256),
        #     nn.ReLU(),
        #     nn.Dropout(0.4),
        #     nn.Linear(256, 2)
        # )

        # self.att1 = torch.nn.Parameter(torch.tensor([0.6, 0.6]))
        # self.att2 = torch.nn.Parameter(torch.tensor([0.6, 0.6]))



    def forward(self, g_rm, g_dm, pos_r, pos_d, drug_feature, disease_feature, protein_feature,
                pos_sample, neg_sample, neg_candidates_r, neg_candidates_d,neg):

        #采用linear映射到同一空间中
        drug_feature = F.elu(self.drug_linear(drug_feature))
        disease_feature = F.elu(self.disease_linear(disease_feature))
        protein_feature = F.elu(self.protein_linear(protein_feature))

        #后面要用
        feature_size=drug_feature.shape[1]

        #transformer进行进一步特征提取
        #测试不使用transformer进行特征提取
        drug_feature1 = drug_feature.unsqueeze(0)
        disease_feature1=disease_feature.unsqueeze(0)
        protein_feature1=protein_feature.unsqueeze(0)

        drug_feature = self.transformer_drug(drug_feature1)
        disease_feature = self.transformer_disease(disease_feature1)
        protein_feature = self.transformer_protein(protein_feature1)

        #此处需要依据数据集进行调整
        # 由相似性矩阵转换为关联矩阵
        #Cdataset
        drug_drug = np.array(pd.read_csv("D:/pyproject/Biowork4/TEMCL/data/C-dataset/drug_drug_baseline.csv", header=None))


        drug_association = generate_association_matrix(drug_drug)
        rr = build_hypergraph(drug_association, self.hyperedge_k)

        # dynamic_k_values = dynamic_knn(drug_drug, k_min=5, k_max=20)
        # rr = build_hypergraph_matrix(drug_drug, dynamic_k_values)

        rr_graph = loadGR1(rr)
        rr_feature=drug_feature
        rr_embedding = self.HGNN(torch.tensor(rr_feature, dtype=torch.float32), torch.tensor(rr_graph, dtype=torch.float32))
        # rr_embedding = self.GCN(torch.tensor(drug_feature, dtype=torch.float32), torch.tensor(drug_association, dtype=torch.float32))
        # rr_embedding = self.GAT(torch.tensor(drug_feature, dtype=torch.float32),torch.tensor(drug_association, dtype=torch.float32))

        #Cdataset
        disease_disease = np.array(pd.read_csv("D:/pyproject/Biowork4/TEMCL/data/C-dataset/disease_disease_baseline.csv", header=None))


        disease_association = generate_association_matrix(disease_disease)
        dd = build_hypergraph(disease_association, self.hyperedge_k)

        # dynamic_k_values = dynamic_knn(disease_disease, k_min=5, k_max=20)
        # dd = build_hypergraph_matrix(disease_disease, dynamic_k_values)

        dd_graph = loadGR1(dd)
        dd_feature=disease_feature
        dd_embedding = self.HGNN(torch.tensor(dd_feature, dtype=torch.float32),torch.tensor(dd_graph, dtype=torch.float32))
        # dd_embedding = self.GCN(torch.tensor(disease_feature, dtype=torch.float32),torch.tensor(disease_association, dtype=torch.float32))
        # dd_embedding = self.GAT(torch.tensor(disease_feature, dtype=torch.float32),torch.tensor(disease_association, dtype=torch.float32))

        r_mp, d_mp = self.mp(g_rm, g_dm, drug_feature, disease_feature, protein_feature)


        #如果取消对比学习，即不使用同构超图进行对比，要用的！！！只是测试重不重要
        l_r = self.contrast_r(r_mp, rr_embedding, pos_r)
        l_d = self.contrast_d(d_mp, dd_embedding, pos_d)

        #使用新的负样本选择策略
        emb_neg_r = self.negative_sampling(r_mp, d_mp, pos_sample, neg_sample, neg_candidates_r)
        emb_neg_d = self.negative_sampling(d_mp, r_mp, pos_sample[:, [1, 0]], neg_sample[:, [1, 0]], neg_candidates_d)

        #为了验证对比学习有效性，对于两个视图上获取到的特征表示采用直接拼接
        # r_emb = torch.cat((r_mp, rr_embedding), dim=1)
        # d_emb = torch.cat((d_mp, dd_embedding), dim=1)
        # emb_neg_r = self.negative_sampling(r_emb, d_emb, pos_sample, neg_sample, neg_candidates_r)
        # emb_neg_d = self.negative_sampling(d_emb, r_emb, pos_sample[:, [1, 0]], neg_sample[:, [1, 0]], neg_candidates_d)

        # 为了验证对比学习有效性，对于两个视图上获取到的特征表示采用矩阵点乘
        # r_emb = torch.mul(r_mp, rr_embedding)
        # d_emb = torch.mul(d_mp, dd_embedding)
        # emb_neg_r = self.negative_sampling(r_emb, d_emb, pos_sample, neg_sample, neg_candidates_r)
        # emb_neg_d = self.negative_sampling(d_emb, r_emb, pos_sample[:, [1, 0]], neg_sample[:, [1, 0]], neg_candidates_d)

        # 为了验证对比学习有效性，对于两个视图上获取到的特征表示采用层注意力机制
        # r_emb = r_mp * self.att1[0] + rr_embedding * self.att1[1]
        # d_emb = d_mp * self.att2[0] + dd_embedding * self.att2[1]
        # emb_neg_r = self.negative_sampling(r_emb, d_emb, pos_sample, neg_sample, neg_candidates_r)
        # emb_neg_d = self.negative_sampling(d_emb, r_emb, pos_sample[:, [1, 0]], neg_sample[:, [1, 0]], neg_candidates_d)


        #此代码为了测试使用随机负样本选择是否会导致模型性能下降，在真正的模型中是不使用这部分代码的
        #负样本选择策略为随机产生
        # if(len(neg)>10000):
        #     emb_neg_r = np.zeros((len(neg), feature_size))
        #     for i in range(len(neg)):
        #         emb_neg_r[i] = (r_mp.detach().numpy())[int(neg[i, 0])]
        #
        #     emb_neg_d = np.zeros((len(neg), feature_size))
        #     for i in range(len(neg)):
        #         emb_neg_d[i] = (d_mp.detach().numpy())[int(neg[i, 1])]
        #
        #     emb_neg_r = torch.tensor(emb_neg_r, dtype=torch.float32)
        #     emb_neg_d = torch.tensor(emb_neg_d, dtype=torch.float32)


        #在进行对比学习后使用的是metapath获取的嵌入表示，论文中要用到！
        r_emb = r_mp
        d_emb = d_mp

        # 不使用负样本选择策略
        # emb_neg_r = r_emb[neg_sample[:, 0]]
        # emb_neg_d = d_emb[neg_sample[:, 1]]

        # torch.mul操作是矩阵点乘，论文中要用到！
        drdi_emb_pos = torch.mul(r_emb[pos_sample[:, 0]], d_emb[pos_sample[:, 1]])
        drdi_emb_neg = torch.mul(emb_neg_r, emb_neg_d)
        drdi_emb = torch.cat((drdi_emb_pos, drdi_emb_neg), dim=0)
        output = self.mlp(drdi_emb)


        # 如果取消对比学习，即不使用同构超图进行对比，要用的
        # lr_note=torch.tensor(0,dtype=torch.float32)
        # return lr_note, output, drdi_emb_pos, drdi_emb_neg

        #模型真正要用的！！！
        return l_r + l_d, output, drdi_emb_pos, drdi_emb_neg


    def negative_sampling(self, emb_r, emb_d, pos_sample, neg_sample, neg_candidates):

        neg_num = neg_sample.shape[0]

        pos_anchor = neg_sample[:, 0]
        pos_target = pos_sample[:, 1]

        emb_anchor = emb_r[pos_anchor]
        emb_pos = emb_d[pos_target]
        emb_neg = emb_d[neg_candidates]

        if self.pool != 'concat':
            emb_anchor = self.pooling(emb_anchor).unsqueeze(dim=1)

        if self.args.negative_rate != 1.0:
            for i in range(int(self.args.negative_rate) - 1):
                emb_pos = torch.cat((emb_pos, emb_pos), dim=0)

        seed = torch.rand(neg_num, 1, 1).to(emb_anchor.device)
        emb_neg = seed * emb_pos.unsqueeze(dim=1) + (1 - seed) * emb_neg

        scores = (emb_anchor.unsqueeze(dim=1) * emb_neg).sum(dim=-1)
        indices = torch.max(scores, dim=1)[1].detach().unsqueeze(dim=1)

        neg_items_emb_ = emb_neg.permute(0, 2, 1)
        emb_neg = neg_items_emb_[[[i] for i in range(neg_num)], range(neg_items_emb_.shape[1]), indices]
        return emb_neg

    def pooling(self, emb):
        if self.pool == 'mean':
            return emb.mean(dim=1)
        elif self.pool == 'sum':
            return emb.sum(dim=1)
        elif self.pool == 'concat':
            return emb.view(emb.shape[0], -1)
        else:  # final
            return emb[:, -1, :]









