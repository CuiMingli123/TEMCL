# TEMCL
TEMCL: Prediction of Drug-disease Associations Based on Transformer and Enhanced Multi-view Contrastive Learning

# Requirements:
- python 3.9.13
- cudatoolkit 11.3.1
- pytorch 1.10.0
- dgl 0.9.0
- networkx 2.8.4
- numpy 1.23.1
- scikit-learn 0.24.2

# Data:
The data files needed to run the model, which contain B-dataset, C-dataset and F-dataset.
- DrugFingerprint, DrugGIP: The similarity measurements of drugs to construct the similarity network
- DiseasePS, DiseaseGIP: The similarity measurements of diseases to construct the similarity network
- Protein_sequence, ProteinGIP_Drug, ProteinGIP_Disease: The similarity measurements of proteins to construct the similarity network
- DrugDiseaseAssociationNumber: The known drug disease associations
- DrugProteinAssociationNumber: The known drug protein associations
- ProteinDiseaseAssociationNumber: The known disease protein associations

# Code:
- data_preprocess.py: Methods of data processing
- metric.py: Metrics calculation
- pos_contrast.py: Get positive and negative samples for contrastive learning
- Contrast.py: Code of graph contrastive learning
- model1.py: Model of TEMCL
- train_DDA1.py: Train the model

# Usage:
Execute ```python train_DDA1.py``` 
