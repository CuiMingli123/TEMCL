import numpy as np
import itertools
from collections import Counter
import time
import pandas as pd
def Eu_dis(x):
    """
    Calculate the distance among each raw of x
    :param x: N X D
                N: the object number
                D: Dimension of the feature
    :return: N X N distance matrix
    """
    x=x
    x = np.mat(x)
    aa = np.sum(np.multiply(x, x), 1)
    ab = x * x.T
    dist_mat = aa + aa.T - 2 * ab
    dist_mat[dist_mat < 0] = 0
    dist_mat = np.sqrt(dist_mat)
    dist_mat = np.maximum(dist_mat, dist_mat.T)
    return dist_mat


def feature_concat(*F_list, normal_col=False):
    """
    Concatenate multiple modality feature. If the dimension of a feature matrix is more than two,
    the function will reduce it into two dimension(using the last dimension as the feature dimension,
    the other dimension will be fused as the object dimension)
    :param F_list: Feature matrix list
    :param normal_col: normalize each column of the feature
    :return: Fused feature matrix
    """
    features = None
    for f in F_list:
        if f is not None and f != []:
            # deal with the dimension that more than two
            if len(f.shape) > 2:
                f = f.reshape(-1, f.shape[-1])
            # normal each column
            if normal_col:
                f_max = np.max(np.abs(f), axis=0)
                f = f / f_max
            # facing the first feature matrix appended to fused feature matrix
            if features is None:
                features = f
            else:
                features = np.hstack((features, f))
    if normal_col:
        features_max = np.max(np.abs(features), axis=0)
        features = features / features_max
    return features


def hyperedge_concat(*H_list):
    """
    Concatenate hyperedge group in H_list
    :param H_list: Hyperedge groups which contain two or more hypergraph incidence matrix
    :return: Fused hypergraph incidence matrix
    """
    H = None
    for h in H_list:
        if h is not None and h != []:
            # for the first H appended to fused hypergraph incidence matrix
            if H is None:
                H = h
            else:
                if type(h) != list:
                    H = np.hstack((H, h))
                else:
                    tmp = []
                    for a, b in zip(H, h):
                        tmp.append(np.hstack((a, b)))
                    H = tmp
    return H


def generate_G_from_H(H, variable_weight=False):
    """
    calculate G from hypgraph incidence matrix H
    :param H: hypergraph incidence matrix H
    :param variable_weight: whether the weight of hyperedge is variable
    :return: G
    """
    if type(H) != list:
        return _generate_G_from_H(H, variable_weight)
    else:
        G = []
        for sub_H in H:
            G.append(generate_G_from_H(sub_H, variable_weight))
        return G

def _generate_G_from_H(H, variable_weight=False):
    """
    calculate G from hypgraph incidence matrix H
    :param H: hypergraph incidence matrix H
    :param variable_weight: whether the weight of hyperedge is variable
    :return: G
    """
    H = np.array(H)
    n_edge = H.shape[1]
    # the weight of the hyperedge
    W = np.ones(n_edge)
    # the degree of the node
    DV = np.sum(H * W, axis=1)
    # the degree of the hyperedge
    DE = np.sum(H, axis=0)
    new_matrix=np.diag(np.power(DE, -1))
    new_matrix[np.isnan(new_matrix) | np.isinf(new_matrix)] = 0.0
    invDE = np.mat(new_matrix)
    new_matrix=np.diag(np.power(DV, -0.5))
    new_matrix[np.isnan(new_matrix) | np.isinf(new_matrix)] = 0.0
    DV2 = np.mat(new_matrix)
    W = np.mat(np.diag(W))
    H = np.mat(H)
    HT = H.T

    if variable_weight:
        DV2_H = DV2 * H
        invDE_HT_DV2 = invDE * HT * DV2
        return DV2_H, W, invDE_HT_DV2
    else:
        G = DV2 * H * W * invDE * HT * DV2
        return G

def build_hypergraph(sim, num_neighbor):
    if num_neighbor > sim.shape[0] or num_neighbor < 0:
        num_neighbor = sim.shape[0]
    neighbor = np.argpartition(-sim, kth=num_neighbor, axis=1)[:, :num_neighbor]
    row_index = np.arange(neighbor.shape[0]).repeat(neighbor.shape[1])
    col_index = neighbor.reshape(-1)
    zero=np.zeros((sim.shape[0],sim.shape[1]))
    zero[row_index, col_index]=sim[row_index, col_index]
    return zero
def build_muti_hypergraph(sim, num_neighbor):
    if num_neighbor > sim.shape[0] or num_neighbor < 0:
        num_neighbor = sim.shape[0]
    neighbor = np.argpartition(-sim, kth=num_neighbor, axis=1)[:, :num_neighbor]
    row_index = np.arange(neighbor.shape[0]).repeat(neighbor.shape[1])
    col_index = neighbor.reshape(-1)
    zero=np.zeros((sim.shape[0],sim.shape[1]))
    zero[row_index, col_index]=sim[row_index, col_index]
    return zero

#实际为构建Gr
def loadGR1(mm):

    dig=np.ones(mm.shape[0])
    I=np.diag(dig)
    H=mm+I
    G =_generate_G_from_H(H)
    return G
#实际为构建Gd
def loadGD1(dd):
    dig = np.ones(dd.shape[0])
    I = np.diag(dig)
    H = dd+I
    G =_generate_G_from_H(H)
    return G

def generate_association_matrix(similarity_matrix):
    n = similarity_matrix.shape[0]
    association_matrix = np.zeros_like(similarity_matrix, dtype=int)

    for i in range(n):
        sorted_indices = np.argsort(similarity_matrix[i])[::-1]
        association_matrix[i, sorted_indices[:7]] = 1

    return association_matrix

#测试超图卷积
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
class HGNN_conv(nn.Module):
    def __init__(self, in_ft, out_ft, bias=True):
        super(HGNN_conv, self).__init__()
        self.dropout = nn.Dropout(0.4)
        self.weight = Parameter(torch.Tensor(in_ft, out_ft))
        self.act = nn.ReLU()
        if bias:
           # self.bias = Parameter(torch.Tensor(out_ft))
            self.bias = nn.Parameter(torch.zeros(out_ft))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()
    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        torch.nn.init.xavier_uniform_(self.weight)
    def forward(self, x: torch.Tensor, G: torch.Tensor):
        # x = torch.matmul(x, self.weight.cuda())
        x = torch.matmul(x, self.weight)
        x = G@x
        if self.bias is not None:
            # x = x + self.bias.cuda()
            x = x + self.bias
        return x
class HGNN_fc(nn.Module):
    def __init__(self, in_ch, out_ch):
        super(HGNN_fc, self).__init__()
        self.fc = nn.Linear(in_ch, out_ch)

    def forward(self, x):
        return self.fc(x)


class HGNN_embedding(nn.Module):
    def __init__(self, in_ch, n_hid, dropout=0.5):
        super(HGNN_embedding, self).__init__()
        self.dropout = dropout
        self.hgc1 = HGNN_conv(in_ch, n_hid)
        self.hgc2 = HGNN_conv(n_hid, n_hid)

    def forward(self, x, G):
        x = F.relu(self.hgc1(x, G))
        x = F.dropout(x, self.dropout)
        x = F.relu(self.hgc2(x, G))
        return x

if __name__ == "__main__":
    #由相似性矩阵转换为关联矩阵
    drug_drug=np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Cdataset/drug_drug_baseline.csv",header=None))
    drug_association = generate_association_matrix(drug_drug)
    #生成超边
    hyperedge_k=20
    rr = build_hypergraph(drug_association, hyperedge_k)
    #构建超图
    rr_graph=loadGR1(rr)
    #获取得到的节点特征
    rr_feature=np.array(pd.read_csv("D:/pyproject/Bioinfomatics_new/DRMAHGC-main/SGMAE/Embedding/C-dataset/drug_test.csv").iloc[:,1:])

    HGNN=HGNN_embedding(64,128)
    rr_embedding=HGNN(torch.tensor(rr_feature,dtype=torch.float32),torch.tensor(rr_graph,dtype=torch.float32))
